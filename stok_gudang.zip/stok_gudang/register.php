<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Register</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        /* Styles */
        body {
            font-family: Arial, sans-serif;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
            background-color: #f4f4f4;
        }

        .register-container {
            background-color: #fff;
            border-radius: 8px;
            padding: 40px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }

        .register-container h2 {
            text-align: center;
            margin-bottom: 30px;
            color: #333;
        }

        .input-group {
            position: relative;
            margin-bottom: 20px;
        }

        .input-group input {
            width: calc(100% - 40px);
            padding: 12px 40px 12px 15px; /* Adjusted padding for the eye icon */
            border: 1px solid #ddd;
            border-radius: 4px;
            outline: none;
            transition: 0.3s;
        }

        .input-group input:focus {
            border-color: #6a7ec1;
        }

        .icon {
            position: absolute;
            color: #aaa;
            top: 50%;
            transform: translateY(-50%);
            cursor: pointer;
        }

        .icon-right {
            right: 10px; /* Adjusted right position for the eye icon */
        }

        .btn-register {
            width: 100%;
            padding: 12px;
            border: none;
            border-radius: 4px;
            color: #fff;
            background-color: #6a7ec1;
            cursor: pointer;
            transition: 0.3s;
        }

        .btn-register:hover {
            background-color: #465da6;
        }
    </style>
</head>
<body>
    <!-- Form Register -->
    <div class="register-container">
        <h2>Register</h2>
        <form action="controller_register.php" method="POST">
            <div class="input-group">
                <i class="fas fa-user icon icon-left"></i>
                <input type="text" name="username" placeholder="Username" required>
            </div>
            <div class="input-group">
                <i class="fas fa-envelope icon icon-left"></i>
                <input type="email" name="email" placeholder="Email" required>
            </div>
            <div class="input-group">
                <i class="fas fa-lock icon icon-left"></i>
                <input type="password" name="password" id="password" placeholder="Password" required>
                <i class="fas fa-eye icon icon-right" onclick="togglePassword()"></i>
            </div>
            <button type="submit" class="btn-register">Register</button>
        </form>
        <p>Sudah memiliki akun? Silahkan <a href="login.php">login disini</a>.</p>
    </div>

    <script>
        function togglePassword() {
            const passwordField = document.getElementById('password');
            const icon = document.querySelector('.icon-right');

            if (passwordField.type === 'password') {
                passwordField.type = 'text';
                icon.classList.remove('fa-eye');
                icon.classList.add('fa-eye-slash');
            } else {
                passwordField.type = 'password';
                icon.classList.remove('fa-eye-slash');
                icon.classList.add('fa-eye');
            }
        }
    </script>
</body>
</html>
