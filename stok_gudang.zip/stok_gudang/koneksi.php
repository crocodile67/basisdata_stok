<?php
$host = "localhost"; // Sesuaikan dengan host database Anda jika tidak menggunakan lokal
$user = "root"; // Username MySQL Anda
$password = ""; // Password MySQL Anda, biasanya kosong jika menggunakan root
$database = "stok_gudang"; // Nama database yang ingin Anda gunakan

$koneksi = new mysqli($host, $user, $password, $database);

if ($koneksi->connect_error) {
    die("Koneksi gagal: " . $koneksi->connect_error);
}
?>
