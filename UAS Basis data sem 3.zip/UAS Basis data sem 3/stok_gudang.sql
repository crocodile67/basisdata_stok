-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 04, 2024 at 02:55 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `stok_gudang`
--

-- --------------------------------------------------------

--
-- Table structure for table `stok`
--

CREATE TABLE `stok` (
  `id` int(11) NOT NULL,
  `nama_produk` varchar(100) NOT NULL,
  `jumlah` int(11) NOT NULL,
  `harga` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `stok`
--

INSERT INTO `stok` (`id`, `nama_produk`, `jumlah`, `harga`) VALUES
(18, 'Indomie Rasa Soto', 100, 3000.00),
(19, 'Indomie Rasa Ayam Bawang', 120, 3000.00),
(20, 'Teh Botol', 80, 5000.00),
(21, 'Kopi Kapal Api', 70, 6000.00),
(23, 'Gula Pasir', 110, 11000.00),
(24, 'Telur Ayam', 85, 3000.00),
(25, 'Minyak Goreng', 75, 14000.00),
(26, 'Susu Ultra', 60, 10000.00),
(27, 'Mi Goreng', 95, 3500.00),
(28, 'Teh Celup Sariwangi', 100, 8000.00),
(29, 'Kopi ABC', 80, 7000.00),
(30, 'Roti Gardenia', 70, 6000.00),
(31, 'Tepung Terigu', 120, 9000.00),
(32, 'Kecap Manis ABC', 100, 5000.00),
(33, 'Sarden ABC', 85, 6000.00),
(34, 'Susu Bendera', 90, 9000.00),
(35, 'Mie Sedap Rasa Ayam Spesial', 110, 3000.00),
(36, 'Susu Bubuk Dancow', 75, 8000.00),
(37, 'Gula Merah', 80, 13000.00),
(38, 'Saus Tomat ABC', 90, 4000.00),
(39, 'Kecap ABC', 100, 4000.00),
(40, 'Biskuit Roma', 120, 6000.00),
(41, 'Sari Roti', 90, 7000.00),
(42, 'Susu Kotak Ultramilk', 85, 6000.00),
(43, 'Sarden Masako', 70, 5000.00),
(44, 'Kopi Luwak', 50, 150000.00),
(45, 'Teh Pucuk Harum', 120, 6000.00),
(46, 'Saus Sambal ABC', 100, 5000.00),
(47, 'Teh Kotak Sosro', 80, 8000.00),
(48, 'Mie Instant Sarimi', 110, 3000.00),
(49, 'Susu UHT Frisian Flag', 95, 7000.00),
(50, 'Sirup Marjan', 70, 6000.00),
(51, 'Sambal ABC', 90, 6000.00),
(52, 'Roti Tawar', 80, 8000.00),
(53, 'Sari Gandum', 75, 9000.00),
(54, 'Kopi Torabika', 100, 7000.00),
(55, 'Mie Instant ABC', 85, 3000.00),
(56, 'Saus Cabe ABC', 90, 4000.00),
(57, 'Teh Javana', 120, 5000.00),
(58, 'Kecap Manis Bango', 95, 6000.00),
(59, 'Kopi ABC Mix', 70, 8000.00),
(60, 'Sambal ABC Special', 100, 6000.00),
(61, 'Susu Ultra Beng-Beng', 80, 10000.00),
(62, 'Teh Celup Tong Tji', 110, 8000.00),
(63, 'Teh Kotak Frestea', 95, 7000.00),
(64, 'Susu Kental Manis Frisian Flag', 75, 9000.00),
(65, 'Roti Kukus', 90, 6000.00),
(66, 'Minyak Goreng Curah', 150, 15000.00),
(67, 'Garam Beryodium', 120, 5000.00),
(68, 'Kopi Bubuk', 180, 9000.00),
(69, 'Tepung Beras', 140, 8000.00),
(70, 'Mie Instan Rasa Ayam', 160, 4000.00),
(71, 'Susu Kental Manis', 130, 12000.00),
(72, 'Gula Pasir', 110, 11000.00),
(73, 'Telur Ayam', 90, 2500.00),
(74, 'Sarden', 70, 6000.00),
(76, 'Kecap Manis', 100, 7000.00),
(77, 'Kecap Asin', 90, 7000.00),
(78, 'Saus Tomat', 80, 5000.00),
(79, 'Susu Bubuk', 120, 8000.00),
(80, 'Teh Celup', 100, 8000.00),
(81, 'Teh Celup Hijau', 80, 9000.00),
(82, 'Kopi Bubuk Instan', 130, 7000.00),
(83, 'Minyak Goreng Kemasan', 150, 16000.00),
(84, 'Sagu', 110, 6000.00),
(85, 'Mie Instan Rasa Pedas', 120, 4000.00),
(86, 'Tepung Terigu', 160, 9000.00),
(87, 'Kacang Tanah', 140, 10000.00),
(88, 'Kacang Hijau', 110, 9000.00),
(89, 'Kacang Merah', 130, 8000.00),
(90, 'Mie Instan Rasa Baso', 120, 4000.00),
(91, 'Mie Instan Rasa Soto', 130, 4000.00),
(92, 'Susu Kental Manis Kaleng', 100, 12000.00),
(93, 'Kopi Bubuk Robusta', 140, 7000.00),
(94, 'Susu Bubuk Full Cream', 120, 9000.00),
(95, 'Minyak Goreng Curah', 150, 15000.00),
(96, 'Teh Celup Manis', 100, 8000.00),
(97, 'Teh Celup Jahe', 90, 9000.00),
(98, 'Kopi Bubuk Arabika', 130, 10000.00),
(99, 'Beras Medium', 150, 13000.00),
(100, 'Susu Bubuk Instant', 120, 8500.00),
(101, 'Minyak Goreng Kemasan 2L', 160, 18000.00),
(102, 'Tepung Maizena', 140, 9500.00),
(103, 'Mie Instan Rasa Kari', 120, 4000.00),
(104, 'Susu Kental Manis Kaleng Kecil', 110, 8000.00),
(105, 'Kopi Bubuk Premium', 120, 12000.00),
(106, 'Minyak Goreng Botol', 180, 20000.00),
(107, 'Teh Celup Rasa Buah', 100, 8500.00),
(108, 'Gula Pasir Halus', 120, 12000.00),
(109, 'Mie Instan Rasa Seafood', 130, 4500.00),
(110, 'Susu Bubuk Cokelat', 100, 10000.00),
(111, 'Minyak Goreng Kemasan 5L', 200, 45000.00),
(112, 'Kecap Manis Botol Kecil', 130, 5000.00),
(113, 'Teh Celup Rasa Madu', 90, 9500.00),
(114, 'Kopi Bubuk Instant Kemasan Kecil', 110, 8500.00),
(115, 'Minyak Goreng Kemasan 1L', 140, 18000.00),
(116, 'Mie Instan Rasa Goreng', 150, 4000.00),
(117, 'Susu Bubuk Coklat Kecil', 120, 8000.00),
(118, 'Tepung Kanji', 100, 8500.00),
(119, 'Kopi Bubuk Hitam', 120, 7500.00),
(120, 'Minyak Goreng 1L', 130, 17000.00),
(121, 'Teh Celup Rasa Jeruk', 140, 9500.00),
(122, 'Gula Pasir Putih', 110, 12000.00),
(123, 'Mie Instan Rasa Pedas Manis', 120, 4500.00),
(124, 'Susu Kental Manis Botol', 100, 10000.00),
(125, 'Minyak Goreng 2L', 150, 18000.00),
(126, 'Teh Celup Rasa Lemon', 130, 9500.00),
(127, 'Kopi Bubuk Robusta Kecil', 120, 7000.00),
(128, 'Minyak Goreng Kemasan 10L', 170, 80000.00),
(129, 'Susu Bubuk Full Cream Kecil', 140, 9000.00),
(130, 'Teh Celup Rasa Anggur', 120, 9500.00),
(131, 'Kopi Bubuk Arabika Kecil', 130, 10000.00),
(132, 'Minyak Goreng Kemasan 20L', 200, 150000.00),
(133, 'Susu Bubuk Instant Kecil', 110, 8500.00),
(134, 'Gula Pasir Kecil', 130, 12000.00),
(135, 'Mie Instan Rasa Ayam Kecil', 140, 4500.00),
(136, 'Susu Kental Manis Kaleng Kecil', 120, 8000.00),
(137, 'Kecap Manis Botol Besar', 100, 12000.00),
(138, 'Teh Celup Rasa Apel', 130, 9500.00),
(139, 'Kopi Bubuk Premium Kecil', 120, 12000.00),
(140, 'Minyak Goreng Kemasan 3L', 160, 19000.00),
(141, 'Susu Bubuk Cokelat Besar', 130, 10000.00),
(142, 'Tepung Terigu Kecil', 120, 8500.00),
(143, 'Kopi Bubuk Hitam Kecil', 130, 7500.00),
(144, 'Minyak Goreng 1L Kecil', 140, 17000.00),
(145, 'Teh Celup Rasa Jeruk Kecil', 150, 9500.00),
(146, 'Gula Pasir Putih Kecil', 160, 12000.00),
(147, 'Mie Instan Rasa Pedas Manis Kecil', 120, 4500.00),
(148, 'Susu Kental Manis Botol Kecil', 100, 10000.00),
(149, 'Air Mineral', 200, 3000.00),
(150, 'Ayam Karkas', 75, 35000.00),
(151, 'Abon Sapi', 20, 25000.00),
(153, 'Anak Jagung', 96, 8000.00),
(154, 'Angetan', 90, 12000.00),
(155, 'Arem-Arem', 80, 10000.00),
(156, 'Aneka Buah Kaleng', 100, 30000.00),
(157, 'Aneka Sarden', 70, 20000.00),
(158, 'Aneka Jamur Kaleng', 60, 18000.00),
(159, 'Acar Mentah', 34, 1000.00),
(161, 'Sarden', 50, 250.00),
(163, 'Indomie Aceh', 1000, 100000.00),
(164, 'Beras', 90, 12000.00),
(165, 'kopi semarang', 1000, 0.00),
(166, 'kopi lampung', 12, 20.00);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `email`, `password`) VALUES
(1, 'luthfi', 'luthfi@gmail.com', '123'),
(3, 'danil', 'codepythn@gmail.com', '123'),
(4, 'adam', 'adam@gmail.com', '123');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `stok`
--
ALTER TABLE `stok`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `stok`
--
ALTER TABLE `stok`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=169;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
