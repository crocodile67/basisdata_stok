<?php
include 'koneksi.php';

// Ambil data produk berdasarkan ID
$id = $_GET['id'];
$sql = "SELECT * FROM stok WHERE id='$id'";
$result = $koneksi->query($sql);

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
} else {
    echo "Data tidak ditemukan.";
    exit();
}

// Memproses data yang diedit
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['id']) && isset($_POST['nama']) && isset($_POST['jumlah']) && isset($_POST['harga'])) {
    $id = $_POST['id'];
    $nama = $_POST['nama'];
    $jumlah = $_POST['jumlah'];
    $harga = $_POST['harga'];
    $harga = str_replace(".", "", $harga); // Menghilangkan titik pemisah ribuan
    // Lanjutkan proses penyimpanan data ke database

    // Update data stok
    $sql = "UPDATE stok SET nama_produk='$nama', jumlah='$jumlah', harga='$harga' WHERE id='$id'";
    if ($koneksi->query($sql) === TRUE) {
        header("Location: dashboard.php");
        exit();
    } else {
        echo "Error: " . $sql . "<br>" . $koneksi->error;
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit Produk</title>
    <link rel="stylesheet" href="edit.css">
</head>
<body>

<h2>Edit Produk</h2>

<form action="" method="POST">
    <input type="hidden" name="id" value="<?php echo $row['id']; ?>">
    <label for="nama">Nama Produk:</label><br>
    <input type="text" id="nama" name="nama" value="<?php echo $row['nama_produk']; ?>"><br>
    <label for="jumlah">Jumlah:</label><br>
    <input type="number" id="jumlah" name="jumlah" value="<?php echo $row['jumlah']; ?>"><br>
    <label for="harga">Harga:</label><br>
    <input type="text" id="harga" name="harga" value="">
    <input type="submit" value="Simpan Perubahan">
</form>

<script>
document.getElementById('harga').addEventListener('input', function (e) {
  let harga = e.target.value;
  harga = harga.replace(/\D/g, "").replace(/\B(?=(\d{3})+(?!\d))/g, ".");
  e.target.value = harga;
});

</script>

</body>
</html>
