<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Login</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        /* Styles */
        body {
            margin: 0;
            padding: 0;
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        .login-container {
            background-color: #fff;
            border-radius: 8px;
            padding: 40px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }

        .login-container h2 {
            text-align: center;
            margin-bottom: 30px;
            color: #333;
        }

        .input-group {
            margin-bottom: 20px;
            position: relative;
        }

        .input-group i {
            position: absolute;
            color: #aaa;
            padding: 12px;
        }

        .input-group input {
            width: calc(100% - 40px);
            padding: 12px 40px 12px 30px;
            border: 1px solid #ddd;
            border-radius: 4px;
            outline: none;
            transition: 0.3s;
        }

        .input-group input:focus {
            border-color: #6a7ec1;
        }

        .toggle-password {
            position: absolute;
            right: 10px;
            top: 8%;
            transform: translateY(-50%);
            cursor: pointer;
            padding: 10px;
        }

        .btn-login {
            width: 100%;
            padding: 12px;
            border: none;
            border-radius: 4px;
            color: #fff;
            background-color: #6a7ec1;
            cursor: pointer;
            transition: 0.3s;
        }

        .btn-login:hover {
            background-color: #465da6;
        }
    </style>
</head>
<body>
    <div class="login-container">
        <h2>Login</h2>
        <form action="controller_login.php" method="POST">
            <div class="input-group">
                <i class="fas fa-user"></i>
                <input type="text" name="username" placeholder="Username">
            </div>
            <div class="input-group">
                <i class="fas fa-lock"></i>
                <input type="password" name="password" id="password" placeholder="Password">
                <span class="toggle-password">
                    <i class="fas fa-eye-slash" id="toggleIcon" onclick="togglePassword()"></i>
                </span>
            </div>
            <button type="submit" class="btn-login">Login</button>
        </form>
        <p>belum memiliki akun?
         <a href="register.php">register disini</a>.</p>
</div>
    </div>

    <script>
        function togglePassword() {
            const passwordField = document.getElementById('password');
            const icon = document.getElementById('toggleIcon');

            if (passwordField.type === 'password') {
                passwordField.type = 'text';
                icon.classList.remove('fa-eye-slash');
                icon.classList.add('fa-eye');
            } else {
                passwordField.type = 'password';
                icon.classList.remove('fa-eye');
                icon.classList.add('fa-eye-slash');
            }
        }
    </script>
</body>
</html>
